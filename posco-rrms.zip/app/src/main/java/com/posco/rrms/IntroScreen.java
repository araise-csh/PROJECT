package com.posco.rrms;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.posco.mobile.office.authchecker.activity.BaseIntroActivity;
import com.posco.mobile.office.authchecker.activity.IPConfigScreen;
import com.posco.mobile.office.authchecker.authentication.CheckAppInstall;
import com.posco.mobile.office.authchecker.authentication.DeviceInfo;
import com.posco.mobile.office.authchecker.authentication.ErrorLogger;
import com.posco.mobile.office.authchecker.authentication.data.AppInfo;
import com.posco.mobile.office.authchecker.authentication.data.AuthCheckInfo;
import com.posco.mobile.office.authchecker.constants.CommonConstant;
import com.posco.mobile.office.authchecker.from.MdmFrom;
import com.posco.mobile.office.authchecker.interfaces.AuthInterface;
import com.posco.mobile.office.authchecker.interfaces.MdmInterface;
import com.posco.mobile.office.authchecker.permission.PermissionCheck;
import com.posco.mobile.office.authchecker.permission.PermissionListener;
import com.posco.mobile.office.authchecker.util.CommandInterface;
import com.posco.mobile.office.authchecker.util.PPreference;

import java.util.ArrayList;

public class IntroScreen extends BaseIntroActivity {
	private static final String TAG = IntroScreen.class.getSimpleName();
	private int IPCONFIG_RESULT = 6660;
	
	//user info
	private String launchOption;
	private String urlPath = null;
	private String urlMessage = null;
	private int urlStauts;
	/**
	 * login resource info
	 */
	private LinearLayout layoutLogin;
	private ImageView imgLogo;
	private EditText etId;
	private EditText etPw;
	private ImageButton btnDeleteId;
	private ImageButton btnDeletePw;
	private RelativeLayout layoutCheckDispPw;
	private CheckBox checkBoxDispPw;
	private Button btnLogin;
	private boolean isCheckedDispPw = false;
	// 인증 요청 스레드
	private boolean isSSOLogin = false;
	
	private float iIPConfig_getX = 0;
	
	private AuthInterface A_Interface = new AuthInterface() {
		@Override
		public void NORMAL(AuthCheckInfo authCheckInfo) {
			startLogic();
		}
		
		@Override
		public void NOTIFICATION(AuthCheckInfo authCheckInfo) {
			showSelectionAlertDialog(authCheckInfo.getMessage(),"확인", getAuthPassCommand(), "취소", getFinishCommand(IntroScreen.this));
		}
		
		@Override
		public void NEW_VERSION(AuthCheckInfo authCheckInfo) {
			showUpdate(authCheckInfo.getMessage(), new CommandInterface() {
				@Override
				public void execute() {
					startLogic();
				}
			});
		}
		
		@Override
		public void ABNORMAL(AuthCheckInfo authCheckInfo) {
			showError(IntroScreen.this, authCheckInfo.getMessage());
		}
		
		@Override
		public void LOGIN(AuthCheckInfo authCheckInfo) {
			if (isSSOLogin) {
				showNutralAlertDialog(authCheckInfo.getMessage(), "확인", new CommandInterface() {
					@Override
					public void execute() {
						loginLogic();
					}
				});
			} else {
				loginLogic();
			}
		}
		
		@Override
		public void FORCE_UPGRADE(AuthCheckInfo authCheckInfo) {
			showFouceUpdate(IntroScreen.this, authCheckInfo.getMessage());
		}
		
		@Override
		public void ERROR(AuthCheckInfo authCheckInfo) {
			if (authCheckInfo.getErrorCode() != null && authCheckInfo.getErrorCode().equals("4110")) {
				showSelectionAlertDialog(authCheckInfo.getMessage(), "종료", getFinishCommand(IntroScreen.this), "확인하기", getBrowserViewCommand());
			} else {
				showNutralAlertDialog(authCheckInfo.getMessage(), "확인", getFinishCommand(IntroScreen.this));
			}
		}
		
		@Override
		public void MDM_INSTALL(AuthCheckInfo authCheckInfo) {
			showMDMInsetall();
		}
		
		@Override
		public void IP_CONFIG() {
			showConfigScreen();
		}
	};
	private MdmInterface M_Interface = new MdmInterface() {
		@Override
		public void NORMAL(MdmFrom mdmFrom) {
			checkAuthority();
		}
	};
	
	/**
	 * Called when the activity is first created.
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		NotificationManager notificationManager = (NotificationManager) getSystemService(Activity.NOTIFICATION_SERVICE);
		notificationManager.cancel(R.layout.activity_intro);
		
		PPreference.getInstance().init(this.getApplicationContext(), getResources().getString(R.string.app_eng_name));

		setContentView(R.layout.activity_intro);
		
		init();
		
		PermissionCheck permissionCheck = new PermissionCheck(IntroScreen.this);
		permissionCheck.setPermissionListener(new PermissionListener() {
			@Override
			public void onPermissionGranted() {
				if(Build.VERSION.SDK_INT >= 29) {
					if (CheckAppInstall.getInstalledPoscoStore(IntroScreen.this)) {
						String path = "posco-store://start?posco_getUniqueDeviceId=true";
						Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(path));
						startActivityForResult(intent, CommonConstant.SOTRE_WINDEVINE_UUID);
					} else {
						Toast.makeText(IntroScreen.this, "포스코스토어가 미설치 상태입니다.", Toast.LENGTH_SHORT).show();
						String path = "http://goo.gl/6wqb";
						Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(path.toString()));
						startActivity(i);
						IntroScreen.this.finish();
					}
				} else {
					AppInfo appInfo = new AppInfo();
					appInfo.setAppId(getResources().getString(R.string.app_id))
							.setAppName(getResources().getString(R.string.app_name))
							.setAppEngName(getResources().getString(R.string.app_eng_name))
							.setUniqueDeviceId(DeviceInfo.getUniqueDeviceId(IntroScreen.this))
							.setDeviceType(getDeviceType(IntroScreen.this))
							.setSsoLogin((PPreference.getInstance().getBoolean("posco_auth_is_first_login_pass", false)) ? "Y" : "N")
							.setLaunchOption(launchOption);
					
					mGlobalVariable.setAppInfo(appInfo);
					
					final Handler handler = new Handler();
					handler.postDelayed(new Runnable() {
						@Override
						public void run() {
							sendMDMCheck(M_Interface);
						}
					}, 1500 );
				}
				
			}
			
			@Override
			public void onPermissionDenied(ArrayList<String> deniedPermissions) {
				IntroScreen.this.finish();
			}
		});
		permissionCheck.setEssentialPermission();
		permissionCheck.setDenyMessage(getString(R.string.msg_permission));
		permissionCheck.setPackageName(IntroScreen.this.getPackageName());
		permissionCheck.check();
		
	}
	
	//====================
	// MDM Check
	//====================
	public void init() {
		//단말에서 설치 후 앱 최초실행 기록
		boolean isFirstRun = PPreference.getInstance().getBoolean(CommonConstant.IS_FIRST_RUN, true);
		if (isFirstRun) {
			PPreference.getInstance().putBoolean(CommonConstant.IS_FIRST_RUN, false);
		}
		
		imgLogo = (ImageView) findViewById(R.id.img_logo);
		layoutLogin = (LinearLayout) findViewById(R.id.layout_login);
		layoutLogin.setVisibility(View.GONE);
		etId = (EditText) findViewById(R.id.input_id);
		etPw = (EditText) findViewById(R.id.input_pw);
		btnDeleteId = (ImageButton) findViewById(R.id.btn_delete_id);
		btnDeleteId.setVisibility(View.GONE);
		btnDeletePw = (ImageButton) findViewById(R.id.btn_delete_pw);
		btnDeletePw.setVisibility(View.GONE);
		layoutCheckDispPw = (RelativeLayout) findViewById(R.id.layout_check_info);
		checkBoxDispPw = (CheckBox) findViewById(R.id.checkbox);
		btnLogin = (Button) findViewById(R.id.btn_login);
		
		etId.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			
			}
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				if (s != null && s.toString().trim().length() > 0) {
					btnDeleteId.setVisibility(View.VISIBLE);
				} else {
					btnDeleteId.setVisibility(View.GONE);
				}
			}
		});
		
		etPw.addTextChangedListener(new TextWatcher() {
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {
			
			}
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
			
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				if (s != null && s.toString().trim().length() > 0) {
					btnDeletePw.setVisibility(View.VISIBLE);
				} else {
					btnDeletePw.setVisibility(View.GONE);
				}
			}
		});
		
		btnDeleteId.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				etId.setText("");
			}
		});
		btnDeletePw.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				etPw.setText("");
			}
		});
		btnLogin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String id = etId.getText().toString();
				String pw = etPw.getText().toString();
				
				if (pw != null && pw.trim().length() > 0) {
					onRequstLogin("SSO", id, pw);
				} else {
					if (pw.trim().length() == 0) {
						showNutralAlertDialog("비밀번호를 입력하세요.", "확인", new CommandInterface() {
							@Override
							public void execute() {
								//none
							}
						});
					}
				}
			}
		});
		layoutCheckDispPw.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				isCheckedDispPw = !isCheckedDispPw;
				checkBoxDispPw.setChecked(isCheckedDispPw);
				if (isCheckedDispPw) {
					etPw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
				} else {
					etPw.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
				}
				int pwLength = etPw.getText().toString().length();
				
				etPw.setSelection(pwLength);
				etPw.invalidate();
				
			}
		});
		etPw.setOnEditorActionListener(new TextView.OnEditorActionListener() {
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				switch (actionId) {
					case EditorInfo.IME_ACTION_DONE:
						String id = etId.getText().toString();
						String pw = etPw.getText().toString();
						
						if (pw != null && pw.trim().length() > 0) {
							onRequstLogin("SSO", id, pw);
						} else {
							if (pw.trim().length() == 0) {
								showNutralAlertDialog("비밀번호를 입력하세요.", "확인", new CommandInterface() {
									@Override
									public void execute() {
										//none
									}
								});
							}
						}
						break;
				}
				return false;
			}
		});
	}
	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (requestCode == IPCONFIG_RESULT && resultCode == Activity.RESULT_OK) {
			sendMDMCheck(M_Interface);
		} else if (requestCode == IPCONFIG_RESULT) {
			showError(this, "아이피 변경 에러입니다.");
		} else if(requestCode == CommonConstant.SOTRE_WINDEVINE_UUID) {
			if(resultCode == RESULT_OK) {
				String android_Id = data.getStringExtra("posco_getUniqueDeviceId");
				PPreference.getInstance().putString("posco_getUniqueDeviceId", android_Id);
				
				AppInfo appInfo = new AppInfo();
				appInfo.setAppId(getResources().getString(R.string.app_id))
						.setAppName(getResources().getString(R.string.app_name))
						.setAppEngName(getResources().getString(R.string.app_eng_name))
						.setUniqueDeviceId(DeviceInfo.getUniqueDeviceId(IntroScreen.this))
						.setDeviceType(getDeviceType(IntroScreen.this))
						.setSsoLogin((PPreference.getInstance().getBoolean("posco_auth_is_first_login_pass", false)) ? "Y" : "N")
						.setLaunchOption(launchOption);
				
				mGlobalVariable.setAppInfo(appInfo);
				
				final Handler handler = new Handler();
				handler.postDelayed(new Runnable() {
					@Override
					public void run() {
						sendMDMCheck(M_Interface);
					}
				}, 1500 );
			} else {
				showNutralAlertDialog("Android 10 ERROR\n단말 정보를 읽어올 수 없습니다. 헬프에 문의해주세요", "확인", new CommandInterface() {
					@Override
					public void execute() {
						finish();
					}
				});
			}
		}
		
	}
	
	@Override
	public void onBackPressed() {
		super.onBackPressed();
	}
	
	private void getIntentData() {
		Intent intent = getIntent();
		this.launchOption = intent.getStringExtra("launchOption");
		if (this.launchOption == null || this.launchOption.equals("")) {
			this.launchOption = CommonConstant.RUN_NORMAL; // 일반실행
		}
	}
	
	//인증 스레드 시작
	private void checkAuthority() {
		sendAuthCheck(A_Interface);
	}
	
	// 인증정보 setting
	private void setAuthInfo() {
		//앱정보
		mGlobalVariable.getAppInfo();
		
		//인증정보
		mGlobalVariable.getDataAuthInfo();

		Log.i(TAG,"AppInfo : " +mGlobalVariable.getAppInfo().getAppId());
		
		Log.i(TAG,"DataAuthInfo: " +mGlobalVariable.getDataAuthInfo().getEmail());


	}
	
	//인증이 정상적으로 되었을 경우 실행 로직 메소드
	private void startLogic() {
		setAuthInfo();
		startApp();
	}
	
	// 앱 실행 로직 메소드
	private void startApp() {
		try {
			Log.i(TAG,"SSO ID : " +mGlobalVariable.getDataAuthInfo().getSsoId());
			String logindID = mGlobalVariable.getDataAuthInfo().getSsoId();		//최초로그인시 or 자동로그인(공용폰)
			if(logindID == null || logindID.equals("null")){
				logindID = mGlobalVariable.getDataAuthInfo().getUserId();		// 개인폰인경우
			}

			if(logindID != null || !logindID.equals("null")) {
				Intent intent = new Intent(IntroScreen.this, MainActivity.class);
				intent.putExtra("loginId", logindID);
				startActivity(intent);
			}else{
				showError(IntroScreen.this, "SSO 로그인 정보를 가져오지 못하였습니다.");
			}
			finish();
		} catch (Exception e) {
			ErrorLogger.printStackTrace(e, ErrorLogger.getInstance());
		}
	}
	
	private void loginLogic() {
		String UserId = mGlobalVariable.getDataAuthInfo().getUserId();
		
		imgLogo.setVisibility(View.INVISIBLE);
		//공용 단말
		if (UserId.indexOf("COMM_DEV") != -1) {
			etId.setText("");
		} else {
			etId.setText(UserId);
		}
		
		if (etId.getText().toString().equals("")) {
			etId.requestFocus();
		} else {
			etPw.requestFocus();
		}
		
		isSSOLogin = true;
		layoutLogin.setVisibility(View.VISIBLE);
	}
	
	private void onRequstLogin(String loginAction, String id, String pw) {
		InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
		imm.hideSoftInputFromWindow(etPw.getWindowToken(), 0);
		
		mSSOId = id;
		mSSOPwd = pw;
		if (loginAction.equals("SSO")) {
			sendSSoAuthCheck(A_Interface);
		}
		layoutLogin.setVisibility(View.GONE);
		imgLogo.setVisibility(View.VISIBLE);
	}
	
	// 인증통과 command
	private CommandInterface getAuthPassCommand() {
		CommandInterface commandInterface = new CommandInterface() {
			public void execute() {
				startLogic();
			}
		};
		return commandInterface;
	}
	
	private void showConfigScreen() {
		Intent intent = new Intent(IntroScreen.this, IPConfigScreen.class);
		startActivityForResult(intent, IPCONFIG_RESULT);
	}
	
}