// common.js

// 최초 생성일 : 19. 11. 01
// 최초 생성자 : hkchoi
// 작업 내용 : Posco 연구시약관리 공통 js

$(document).ready(function(){

	// Sub menu Drop down 스크립트
	$(".gnb_menu > ul > li > a").on("click", function(){
		
		// 메뉴에 Sub menu가 있다면
		if($(this).siblings().length > 0) {
			event.preventDefault();
			$(this).parent().toggleClass("active").toggleClass("open");
			$(this).siblings(".sub_menu").slideToggle("fast");
			
			// 메뉴에 다른 Sub menu가 열려있다면
			if ($(this).parents("ul").children(".sub_menu").css("display","block")) {
				$(this).parent("li").siblings().removeClass("active open");
				$(this).parent("li").siblings().children(".sub_menu").slideUp("fast");
			}
		}
		
	});
	
	// 메뉴 이동 했을 때 Gnb 메뉴 상태 스크립트
	$(".gnb_menu > ul > li.active").children(".sub_menu").css("display","block");
	
	// 전체 메뉴 중에서 Sub menu가 한개도 없을 때 전체 List에 화살표 빼기 스크립트 
	//if($(".gnb_menu > ul > li > a").siblings().length == 0) {
	//	$(".gnb_menu > ul > li > a").addClass("no_sub_menu");
	//}
	
	// 메뉴 중에서 Sub menu가 없을 때 해당 메뉴 화살표 빼기 스크립트 
	$(".gnb_menu > ul > li:not(:has(ul))").children("a").addClass("no_sub_menu");
	
	//Modal Trigger 스크립트
	$(".modal_trigger").click(function(){
		var attrID = $(this).attr("id")
		$("#" + attrID + "Modal").dialog("open");
	});
	
	//공통 모달(confirm) 스크립트 (확인, 취소 등등 confirm 화면)
	$(".alert_dialog").dialog({
		create:function () {
			$(".ui-dialog-titlebar").hide();
			$(".modal_close").click(function(){
				$(this).closest(":ui-dialog").dialog("close");
			});
		},
		autoOpen:false,
		closeOnEscape: false,
		modal:true,
		draggable:false,
		minHeight:100,
		width:"46.75vh",
		open: function (event, ui) {
		$("body").css("overflow", "hidden");
	  },
		close: function (event, ui) {
		$("body").css("overflow", "");
	  }
	});
	
	//기능 모달 스크립트
	$(".func_dialog").dialog({
		create:function(){
			$(".modal_close").click(function(){
				$(this).closest(":ui-dialog").dialog("close");
			});
		},
		autoOpen:false,
		closeOnEscape: false,
		modal:true,
		draggable:false,
		minHeight:100,
		width:"46.75vh",
		open: function (event, ui) {
			$('.ui-dialog-titlebar-close').hide();
			$("body").css("overflow", "hidden"); 
			$('.ui-dialog .form_control').blur();
		  },
		close: function (event, ui) {
		$("body").css("overflow", "");
	  }
	});
	
	//완료 모달 스크립트(전체 모달 닫기)
	$("#completeModal .modal_close, #resetModal .modal_close").click(function(){
		$(".alert_dialog:ui-dialog, .func_dialog:ui-dialog").dialog("close");
	});
	
	///////////////////////////임시보류//////////////////////////
	//공통 모달(confirm) 스크립트 (확인, 취소 등등 confirm 화면)
//	$(".alert_dialog").dialog({
//		create:function () {
//			$(".ui-dialog-titlebar").hide();
//			$(".modal_close").click(function(){
//				$(this).closest(":ui-dialog").dialog("close");
//			});
//		},
//		autoOpen:false,
//		closeOnEscape: false,
//		modal:true,
//		draggable:false,
//		minHeight:100,
//		resizable:false,
//		width:"46.75vh",
//		open: function (event, ui) {
//			$("body").css("overflow", "hidden");
//			
//	  	},
//		close: function (event, ui) {
//			$("body").css("overflow", "");
//	  	}
//	});
//	
//	//기능 모달 스크립트
//	$(".func_dialog").dialog({
//		create:function(){
//			$('.ui-dialog-titlebar-close').hide();
//			$(".modal_close").click(function(){
//				$(this).closest(":ui-dialog").dialog("close");
//			});
//		},
//		autoOpen:false,
//		closeOnEscape: false,
//		modal:true,
//		draggable:false,
//		minHeight:100,
//		resizable:false,
//		width:"52.75vh",
//		open: function (event, ui) {
//			$("body").css("overflow", "hidden"); 
//			$('.ui-dialog .form_control').blur();
//		  },
//		close: function (event, ui) {
//			$("body").css("overflow", "");
//	  }
//	});
//	
//	//완료 모달 스크립트(전체 모달 닫기)						 
//	$("#completeModal, #resetModal").dialog({
//		buttons: [
//			{
//				text: "확인",
//				click: function() {
//					$(this).dialog("close");
//					$(".alert_dialog:ui-dialog, .modeless:ui-dialog").dialog("close");
//				},
//				class:"btn btn_dblue"
//			}
//		]
//	}).on(function(){
//		var modalID = $(this).attr("id");
//		$("#" + modalID).siblings(".btn_area").appendTo($("#" + modalID));
//	}).parent(".ui-dialog").find(".ui-dialog-buttonpane").removeClass("ui-dialog-buttonpane ui-widget-content ui-helper-clearfix").addClass("btn_area").find("button").removeClass("ui-button ui-corner-all ui-widget");
//
//	// 모달 스크립트 공통 스타일 스크립트
//	$(".alert_dialog .btn_area button, .func_dialog .btn_area button").removeClass("ui-button ui-corner-all ui-widget");
	///////////////////////////임시보류//////////////////////////
	
	
	// 작원 조회 샘플 데이터
	var mydata = [
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'},
		{'employeeNum':'4641324', 'name':'홍길동', 'departmentName':'안전환경관리섹션', 'area':'포항'}
	];
	
	// 직원조회 jqGrid 스크립트
	$("#selPeopleList").jqGrid({
		datatype: "local",
		data:mydata,
		mtype: "POST",
		colNames:['직번', '성명', '부서명', '지역'], 
		colModel:[
			{name:'employeeNum',align:"center", width:100, editable:true},
			{name:'name', align:"center", width:60},
			{name:'departmentName', align:"left", width:200},
			{name:'area', align:"center", width:60},
		 ],
		height : "100%",
		// rowNum : 5, // 1페이지 리스트 노출 개수.
		hoverrows:false,
		autoWidth:true,
		shrinkToFit:false
	});
	
	$("*").removeClass("ui-corner-all");
	
});

// GNB 열고 닫기 스크립트
function openGnb (){
	$("#gnbWrapper").addClass("open");
	$("#gnbWrapper").before("<div class='gnb_overlay' onclick='javascript:closeGnb();'></div>");
	$("body").css("height:", "100%");
	$(".gnb_overlay").on("mousewheel scroll touchmove",function(e){
	     event.preventDefault();
	     event.stopPropagation();
           return false;
	});
}

function closeGnb (){
	$("#gnbWrapper").removeClass("open");
	$(".gnb_overlay").remove();
	$("body").css("height","auto");
}

// Processing 애니메이션 스크립트
function processing () {
	setTimeout(function(){
		$("#processingModal:ui-dialog").dialog("close");
		$("#completeModal").dialog("open");
	}, 3500);
}